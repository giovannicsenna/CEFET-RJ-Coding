#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>

#define MAX_LINE 1024
#define MAX_ARGS 100
#define MAX_PATHS 100
#define ERROR_MSG "An error has occurred\n"

char* paths[MAX_PATHS];
int path_count = 0;

void print_error() {
    write(STDERR_FILENO, ERROR_MSG, strlen(ERROR_MSG));
}

char* trim(char* s) {
    if (!s) return NULL;
    while(*s==' '||*s=='\t'||*s=='\n'||*s=='\r') s++;
    if(*s==0) return s;
    char* end = s + strlen(s)-1;
    while(end > s && (*end==' '||*end=='\t'||*end=='\n'||*end=='\r')) { *end=0; end--; }
    return s;
}

char** parse_tokens(char* cmd, int* argc) {
    if (!cmd) { *argc=0; return NULL; }
    char** argv = malloc(MAX_ARGS * sizeof(char*));
    if (!argv) { print_error(); exit(1); }
    int i = 0;
    char* token = strtok(cmd, " \t\r\n");
    while (token && i < MAX_ARGS-1) { argv[i++] = token; token = strtok(NULL," \t\r\n"); }
    argv[i] = NULL; *argc = i;
    return argv;
}

void builtin_path(int argc, char** argv) {
    for(int i=0;i<path_count;i++){ free(paths[i]); paths[i]=NULL; }
    path_count=0;
    for(int i=1;i<argc;i++){ if(path_count<MAX_PATHS) paths[path_count++]=strdup(argv[i]); }
}

void builtin_cd(int argc, char** argv) {
    if(argc != 2 || chdir(argv[1]) != 0) print_error();
}

int execute_command(char** argv, int argc, char* out_file, int background, pid_t* bg_pids, int* bg_count) {
    if(argc==0 || argv==NULL) return 0;

    if(strcmp(argv[0],"exit")==0){
        if(argc != 1) print_error(); else exit(0);
        return 0;
    }
    if(strcmp(argv[0],"cd")==0){ builtin_cd(argc,argv); return 0; }
    if(strcmp(argv[0],"path")==0){ builtin_path(argc,argv); return 0; }

    for(int i=0;i<path_count;i++){
        if(!paths[i]) continue;
        char full[1024]; snprintf(full,sizeof(full),"%s/%s",paths[i],argv[0]);
        if(access(full,X_OK)==0){
            pid_t pid=fork();
            if(pid<0){ print_error(); return 1; }
            if(pid==0){
                if(out_file){
                    int fd = open(out_file, O_CREAT|O_WRONLY|O_TRUNC, 0644);
                    if(fd<0){ print_error(); exit(1);}
                    if(dup2(fd, STDOUT_FILENO)<0 || dup2(fd, STDERR_FILENO)<0){ print_error(); exit(1);}
                    close(fd);
                }
                execv(full, argv);
                print_error();
                exit(1);
            } else {
                if(background){
                    bg_pids[(*bg_count)++] = pid;
                } else {
                    waitpid(pid,NULL,0);
                }
                return 0;
            }
        }
    }
    print_error();
    return 1;
}

void reap_background_children() {
    int status;
    while(waitpid(-1,&status,WNOHANG)>0);
}

int main(int argc_main, char* argv_main[]) {
    FILE* input = stdin;
    char line[MAX_LINE];
    path_count=0;
    paths[path_count++] = strdup("/bin");
    paths[path_count++] = strdup("."); // diretório atual para testes OSTEP
    if(!paths[0] || !paths[1]) { print_error(); exit(1); }

    if(argc_main>2){ print_error(); exit(1);}
    else if(argc_main==2){
        input = fopen(argv_main[1], "r");
        if(!input){ print_error(); exit(1);}
    }

    while(1){
        reap_background_children();
        if(input==stdin){ printf("wish> "); fflush(stdout);}
        if(fgets(line,sizeof(line),input)==NULL) break;

        size_t len = strlen(line);
        if(len>0 && line[len-1]=='\n') line[len-1]=0;

        pid_t bg_pids[MAX_ARGS];
        int bg_count = 0;

        char* saveptr;
        char* segment = strtok_r(line,"&",&saveptr);
        while(segment){
            char* cmd = trim(segment);
            int background = 1;
            if(!cmd || strlen(cmd)==0){ segment = strtok_r(NULL,"&",&saveptr); continue; }

            char* out_file = NULL;
            char* redir = strchr(cmd,'>');
            if(redir){
                *redir = 0;
                redir++;
                char* fname = trim(redir);
                if(!fname || strlen(fname)==0 || strchr(fname,' ')){ print_error(); segment = strtok_r(NULL,"&",&saveptr); continue; }
                out_file = strdup(fname);
                cmd = trim(cmd);
                if(!cmd || strlen(cmd)==0){ print_error(); free(out_file); segment = strtok_r(NULL,"&",&saveptr); continue; }
            }

            int argc_cmd = 0;
            char* cmd_copy = strdup(cmd);
            if(!cmd_copy){ print_error(); segment = strtok_r(NULL,"&",&saveptr); continue; }
            char** argv_cmd = parse_tokens(cmd_copy, &argc_cmd);

            if(argc_cmd>0)
                execute_command(argv_cmd, argc_cmd, out_file, background, bg_pids, &bg_count);

            if(argv_cmd) free(argv_cmd);
            if(cmd_copy) free(cmd_copy);
            if(out_file) free(out_file);

            segment = strtok_r(NULL,"&",&saveptr);
        }

        // Espera todos os processos em background da linha
        for(int i=0;i<bg_count;i++) waitpid(bg_pids[i],NULL,0);
    }

    for(int i=0;i<path_count;i++) free(paths[i]);
    if(input!=stdin) fclose(input);
    return 0;
}

/* comandos úteis */
//echo "aaaaabbc" > teste.txt => cria arquivo de texto
//gcc wish.c -o wish => compilador
//./wish teste.txt => roda com o teste
//cd wish_codigo => entra na pasta
//ls => lista tudo dentro
//git clone https://github.com/igorcompuff/ostep-projects.git => para baixar testes
//cd => entrada na pasta do wish
//gcc -o wish
// wish.c -Wall -Werror => compilar com os comentários
//./test-wish.sh => roda os testes
//cd ~/ostep-projects/initial-utilities/wish => entra na pasta de análise do código direto do terminal
//nano wish.c => interface de edição
//diff tests/x.out tests-out/x.out => realiza o teste específico, o x é o num do teste
//diff -y tests/x.out tests-out/x.out => Compara o teste com a saída do código, x é o num do teste
//home/g10v4nn1/ostep-projects/processes-shell => Pasta dos testes