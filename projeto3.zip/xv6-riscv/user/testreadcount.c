#include "kernel/types.h"
#include "user/user.h"

int
main(void)
{
  printf("contador inicial: %d\n", getreadcount());

  char buf[10];

  printf("Digite um caractere: ");
  read(0, buf, 1);

  printf("contador final: %d\n", getreadcount());

  exit(0);
}
